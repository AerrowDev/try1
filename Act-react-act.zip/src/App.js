import './App.css';
import Appbar from './Appbar';
import Demo from './Demo';

function App() {
  return (
    <div className="App">
    
      <Appbar/>
        <Demo/>
    </div>
  );
}

export default App;
